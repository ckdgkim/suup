import { createContext } from "react";

const Context = createContext({
  type: "show",
  color: "yellow",
});

export default Context;
